/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EjemploBicicletaComposicion;

/**
 *
 * @author ProDep-1
 */
public class Rueda {
    private String nombre;
    public Rueda(String n){
        this.nombre=n;
    }
    
    public String getNombre(){
        return nombre;
    }
}
